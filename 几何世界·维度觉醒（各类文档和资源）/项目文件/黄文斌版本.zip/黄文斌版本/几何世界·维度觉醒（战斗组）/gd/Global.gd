extends Node

var can_choose_skill : Array = [] #玩家可以搭配拖动的技能
var drag_skill : String = ''  #玩家拖动的技能
