# Projectile.gd
# 投射物的基础脚本，处理移动和碰撞逻辑
extends Area2D

# 投射物的基础属性，可在编辑器中调整
@export var speed = 500      # 移动速度（像素/秒）
@export var damage = 10      # 基础伤害值
@export var fire_effect = false  # 是否附带火焰效果

# 投射物的移动方向，默认向右
var direction = Vector2.RIGHT

# 每个物理帧更新投射物位置
func _physics_process(delta):
	# 根据方向、速度和时间增量更新位置
	position += direction * speed * delta

# 当投射物与其他物体发生碰撞时调用
func _on_Projectile_body_entered(body):
	# 检查碰撞目标是否可以受到伤害
	if body.has_method("take_damage"):
		# 对目标造成伤害
		body.take_damage(damage)
		# 如果启用了火焰效果，则施加燃烧状态
		if fire_effect:
			body.apply_burn()
	# 碰撞后销毁投射物
	queue_free()
