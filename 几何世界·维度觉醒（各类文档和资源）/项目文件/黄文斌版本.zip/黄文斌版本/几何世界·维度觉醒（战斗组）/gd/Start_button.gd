extends Button

func _on_StartButton_pressed():
	# 从动态Slot容器中收集技能
	var slot_container = $"../技能槽/动态添加的Slot容器"
	if not slot_container:
		print("错误：找不到动态Slot容器！")
		return
		
	var skills = slot_container.get_all_skills()
	print("收集到的技能：", skills)
	
	# 必须至少选择"点"
	if "点" in skills:
		# 设置技能
		var skill_manager = get_node("/root/SkillManager")
		if skill_manager:
			skill_manager.set_skills(skills)
			print("成功设置技能到技能管理器")
			print("当前技能列表：", skill_manager.selected_skills)
			print("技能列表大小：", skill_manager.selected_skills.size())
			
			# 切换到主场景
			get_tree().change_scene_to_file("res://scenes/Main.tscn")
		else:
			print("错误：找不到技能管理器！")
	else:
		print("错误：必须至少选择'点'技能！")

# 从动态添加的Slot容器中收集技能
func collect_skills_from_dynamic_slots() -> Array:
	var skills = []
	var slots_container = $"../技能槽/动态添加的Slot容器"
	
	if not slots_container:
		print("错误：找不到动态添加的Slot容器！")
		return skills
		
	print("找到动态添加的Slot容器")
	print("容器中的子节点数量：", slots_container.get_child_count())
	
	for slot in slots_container.get_children():
		print("检查Slot节点：", slot.name)
		
		# 检查是否是有效的技能槽
		if slot.has_method("get_skill"):
			var skill = slot.get_skill()
			if skill != null and skill != "":
				print("从Slot获取到技能：", skill)
				skills.append(skill)
			else:
				print("Slot中没有技能")
		else:
			print("警告：该节点不是有效的技能槽")
	
	print("收集完成，技能列表：", skills)
	return skills

# 在开始按钮点击时验证组合有效性
func validate_skills(skills: Array) -> bool:
	if skills.is_empty():
		print("错误：技能列表为空！")
		return false
		
	if not "点" in skills:
		print("错误：必须包含基础'点'技能！")
		return false
		
	print("技能组合验证通过")
	return true

func _on_动态添加的slot容器_mouse_exited():
	pass # Replace with function body.


func _on_button_down():
	get_tree().change_scene_to_file("res://scenes/Main.tscn")
