extends HBoxContainer

const SlotScene = preload("res://scenes/Slot.tscn")

var is_mouse_hovering = false

func _ready():
	# 初始创建一个空槽
	add_empty_slot()
	
	# 确保可以接收鼠标事件
	mouse_filter = MOUSE_FILTER_STOP

func add_empty_slot():
	var new_slot = SlotScene.instantiate()
	add_child(new_slot)

func check_add_new_slot():
	# 获取所有子节点（技能槽）
	var children = get_children()
	# 如果最后一个槽已经有技能，则添加新的空槽
	if children.size() > 0 and children[-1].current_skill != null:
		add_empty_slot()

func _on_mouse_entered():
	is_mouse_hovering = true

func _on_mouse_exited():
	is_mouse_hovering = false

func _process(delta):
	pass
	#print(is_mouse_hovering)
	
func _input(event):
	# 当鼠标在技能槽区域内且释放左键时
	if is_mouse_hovering and event.is_action_released("left_press"):
		# 如果正在拖拽技能
		if Global.drag_skill != '':
			# 尝试将技能添加到最后一个空槽
			var slots = get_children()
			for slot in slots:
				if slot.current_skill == null:
					# 将拖拽的技能添加到空槽
					slot.set_skill(Global.drag_skill)
					# 清除拖拽状态
					Global.drag_skill = ''
					# 检查是否需要添加新的空槽
					check_add_new_slot()
					break
