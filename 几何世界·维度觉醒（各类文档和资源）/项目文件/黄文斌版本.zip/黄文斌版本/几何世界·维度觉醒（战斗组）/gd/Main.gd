extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready():
	print("Main场景加载完成")
	print("当前所有技能：", SkillManager.selected_skills)
	
	# 检查玩家节点
	var player = get_node("player")
	if player:
		print("玩家节点已找到")
		print("玩家位置：", player.position)
		print("玩家可见性：", player.visible)
		
		# 确保玩家可见
		player.show()
		player.position = Vector2(576, 324)  # 设置到屏幕中心
		player.modulate.a = 1.0  # 确保不透明
	else:
		print("错误：找不到玩家节点！")
	
	# 如果没有选择技能，返回技能选择场景
	if SkillManager.selected_skills.is_empty():
		print("没有选择技能，返回选择界面")
		get_tree().change_scene_to_file("res://scenes/SkillSelection.tscn")
		return
	
	# 重置技能索引
	SkillManager.reset_skill_index()


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta):
	pass
