# Bullet.gd
extends Area2D

# 子弹基础属性
var damage: float = 10
var speed: float = 500
var direction: Vector2 = Vector2.ZERO
var shooter = null  # 存储发射者的引用
var skill_type: String = ""  # 添加技能类型属性
var fire_damage: float = 0
var fire_duration: float = 0

# 火焰效果
var has_fire_effect: bool = false

# 当节点准备就绪时调用
func _ready() -> void:
	$LifetimeTimer.wait_time = 2
	$LifetimeTimer.start()
	print("子弹初始化")
	print("技能类型：", skill_type)
	print("伤害：", damage)
	print("速度：", speed)
	print("方向：", direction)
	
	# 根据技能类型设置子弹外观
	update_bullet_appearance()

# 物理帧更新时调用，处理子弹移动
func _physics_process(delta: float) -> void:
	position += direction * speed * delta

# 设置子弹属性
func setup(effects: Dictionary, shoot_direction: Vector2, shooter_node = null, skill_name: String = "") -> void:
	damage = effects.damage
	speed = effects.speed
	direction = shoot_direction
	has_fire_effect = effects.has_fire
	fire_damage = effects.fire_damage
	fire_duration = effects.fire_duration
	shooter = shooter_node  # 保存发射者引用
	skill_type = skill_name  # 保存技能类型
	
	# 根据效果调整子弹外观
	update_bullet_appearance()

# 更新子弹外观
func update_bullet_appearance():
	var sprite = $Sprite2D
	if not sprite:
		print("错误：找不到子弹精灵节点！")
		return
		
	# 根据技能类型设置外观
	match skill_type:
		"点":
			sprite.modulate = Color.WHITE
		"火焰附着":
			sprite.modulate = Color.RED
		"数量×2", "数量×3":
			sprite.modulate = Color.YELLOW
		_:
			sprite.modulate = Color.WHITE
	
	print("设置子弹外观：", skill_type)

# 击中目标时的处理
func _on_body_entered(body: Node) -> void:
	# 忽略与发射者的碰撞
	if body == shooter:
		return
		
	if body.has_method("take_damage"):
		# 造成基础伤害
		body.take_damage(damage)
		
		# 如果有火焰效果，施加持续伤害
		if has_fire_effect and body.has_method("apply_burn"):
			body.apply_burn(fire_damage, fire_duration)
	
	# 销毁子弹
	queue_free()

# 生命周期结束时的回调函数
func _on_lifetime_timer_timeout() -> void:
	queue_free()

func _on_visible_on_screen_notifier_2d_screen_exited():
	queue_free()  # 当子弹离开屏幕时销毁它
