extends Node2D

var float_speed = Vector2(0, -100)  # 向上浮动的速度
var fade_time = 1.0  # 淡出时间
var initial_scale = Vector2(1, 1)  # 初始大小
var pop_scale = Vector2(1.5, 1.5)  # 弹出时的大小

func _ready():
	# 设置初始缩放
	scale = initial_scale
	
	# 创建弹出动画
	var tween = create_tween()
	tween.tween_property(self, "scale", pop_scale, 0.1)
	tween.tween_property(self, "scale", initial_scale, 0.1)
	
	# 创建淡出动画
	tween = create_tween()
	tween.tween_property(self, "modulate:a", 0.0, fade_time)
	tween.tween_callback(queue_free)

func _process(delta):
	# 向上浮动
	position += float_speed * delta

func set_damage(amount: float) -> void:
	# 设置伤害数字
	$Label.text = str(int(amount))
	
	# 如果是暴击，使用不同的颜色和大小
	if amount >= 20:  # 暴击阈值
		$Label.add_theme_color_override("font_color", Color(1, 0.5, 0, 1))  # 橙色
		scale = pop_scale  # 更大的大小 