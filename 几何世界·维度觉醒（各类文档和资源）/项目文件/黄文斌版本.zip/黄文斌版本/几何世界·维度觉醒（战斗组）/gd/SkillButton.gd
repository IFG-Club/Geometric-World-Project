extends TextureButton

@export var skill_name = self.name

#@onready var main = get_node("/root/Main")


# 在SkillButton.gd的_ready()中添加（可选）
func _ready():
	custom_minimum_size = Vector2(64, 64)  # 确保拖拽预览有合理尺寸
	Global.can_choose_skill.append(self.name)
	print(Global.can_choose_skill)
	

func _get_drag_data(position):
# 创建拖拽数据包
	var data = {
		"skill": self.name,
		"source": self
	}
	
	# 创建拖拽预览
	var drag_preview = TextureRect.new()
	drag_preview.texture = self.texture_normal
	drag_preview.size = self.size
	Global.drag_skill = self.name
	set_drag_preview(drag_preview)
	
	return data

# 添加输入事件处理（可选）
func _gui_input(event):
	if event is InputEventMouseMotion:
		if event.button_mask == MOUSE_BUTTON_MASK_LEFT:
			get_viewport().set_input_as_handled()
	

func _on_SkillButton_mouse_entered():
	show_tooltip(self.name)

func show_tooltip(skill_name):
	# 显示对应的技能描述
	pass
