# SkillManager.gd
# 全局技能管理器，负责管理和追踪已选择的技能
extends Node

# 存储当前选择的技能列表
# 这个数组会被其他脚本（如 Player.gd）访问以获取技能效果
var selected_skills: Array = []
var current_skill_index: int = 0  # 当前使用的技能槽索引

func _ready():
	print("SkillManager初始化")
	# 确保至少有基础技能"点"
	if selected_skills.is_empty():
		selected_skills = ["点"]
		print("添加基础技能'点'")
	print("初始技能列表：", selected_skills)

# 设置技能列表
func set_skills(skills: Array) -> void:
	if skills.is_empty():
		print("警告：试图设置空技能列表，保持基础技能'点'")
		selected_skills = ["点"]
	else:
		selected_skills = skills.duplicate()
	current_skill_index = 0
	print("设置新的技能列表：", selected_skills)
	print("技能列表大小：", selected_skills.size())

# 基础技能效果
const BASE_DAMAGE = 10
const BASE_SPEED = 500
const BASE_SIZE = Vector2(1, 1)

# 技能效果配置
const SKILL_EFFECTS = {
	"点": {
		"damage": 10,
		"speed": 500,
		"description": "基础攻击，发射一颗子弹"
	},
	"火焰附着": {
		"damage_multiplier": 1.5,
		"dot_damage": 5,
		"dot_duration": 3,
		"description": "增加50%伤害并附加持续燃烧效果"
	},
	"数量×2": {
		"count_multiplier": 2,
		"spread_angle": 15,
		"description": "发射数量翻倍，呈扇形散射"
	},
	"数量×3": {
		"count_multiplier": 3,
		"spread_angle": 30,
		"description": "发射数量变为三倍，呈扇形散射"
	}
}

# 获取当前技能
func get_current_skill() -> String:
	print("获取当前技能")
	print("技能列表：", selected_skills)
	print("当前索引：", current_skill_index)
	
	if selected_skills.is_empty():
		print("技能列表为空，添加基础技能'点'")
		selected_skills = ["点"]
		current_skill_index = 0
	
	if current_skill_index >= selected_skills.size():
		current_skill_index = 0
		print("重置技能索引为0")
	
	var current_skill = selected_skills[current_skill_index]
	print("返回当前技能：", current_skill)
	return current_skill

# 切换到下一个技能
func next_skill() -> void:
	if selected_skills.is_empty():
		print("技能列表为空，添加基础技能'点'")
		selected_skills = ["点"]
		current_skill_index = 0
		return
	
	current_skill_index = (current_skill_index + 1) % selected_skills.size()
	print("切换到技能：", selected_skills[current_skill_index])

# 重置技能索引
func reset_skill_index() -> void:
	current_skill_index = 0
	print("重置技能索引")
	if not selected_skills.is_empty():
		print("当前技能：", selected_skills[current_skill_index])

# 获取当前技能的效果
func get_current_skill_effects() -> Dictionary:
	var current_skill = get_current_skill()
	return calculate_skill_effects([current_skill])

# 计算最终的技能效果
func calculate_skill_effects(skills: Array) -> Dictionary:
	var effects = {
		"damage": BASE_DAMAGE,
		"speed": BASE_SPEED,
		"count": 1,
		"size": BASE_SIZE,
		"has_fire": false,
		"fire_damage": 0,
		"fire_duration": 0,
		"spread_angle": 0
	}
	
	if skills.is_empty():
		return effects
		
	for skill in skills:
		match skill:
			"点":
				effects.damage = SKILL_EFFECTS["点"].damage
				effects.speed = SKILL_EFFECTS["点"].speed
			
			"火焰附着":
				effects.damage *= SKILL_EFFECTS["火焰附着"].damage_multiplier
				effects.has_fire = true
				effects.fire_damage = SKILL_EFFECTS["火焰附着"].dot_damage
				effects.fire_duration = SKILL_EFFECTS["火焰附着"].dot_duration
			
			"数量×2":
				effects.count *= SKILL_EFFECTS["数量×2"].count_multiplier
				effects.spread_angle = SKILL_EFFECTS["数量×2"].spread_angle
			
			"数量×3":
				effects.count *= SKILL_EFFECTS["数量×3"].count_multiplier
				effects.spread_angle = SKILL_EFFECTS["数量×3"].spread_angle
	
	return effects

# 获取技能描述
func get_skill_description(skill_name: String) -> String:
	if SKILL_EFFECTS.has(skill_name):
		return SKILL_EFFECTS[skill_name].description
	return "未知技能"
