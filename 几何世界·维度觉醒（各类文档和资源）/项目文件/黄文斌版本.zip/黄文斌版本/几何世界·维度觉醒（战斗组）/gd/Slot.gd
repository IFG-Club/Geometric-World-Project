extends Control

var current_skill: String = ""  # 初始化为空字符串而不是null
@onready var skill_manager = get_node("/root/SkillManager")

# 关键点1：必须关联到正确的Control节点
func can_drop_data(_at_position, data):
	print("检查是否可以放置技能")
	print("拖放数据：", data)
	return data is Dictionary and data.has("skill") and current_skill == ""

# 关键点2：处理实际放置逻辑
func drop_data(_at_position, data):
	print("放置技能")
	if data is Dictionary and data.has("skill"):
		current_skill = data["skill"]
		print("设置技能：", current_skill)
		update_display()
		
		# 触发新槽位生成
		var parent = get_parent()
		if parent and parent.has_method("check_add_new_slot"):
			parent.check_add_new_slot()
		return true
	return false

# 关键点3：确保可见区域接受输入
func _ready():
	print("技能槽初始化")
	print("初始技能：", current_skill)
	custom_minimum_size = Vector2(64, 64)  # 设置最小尺寸
	mouse_filter = Control.MOUSE_FILTER_STOP  # 确保可以接收鼠标事件
	set_process_input(true)  # 启用输入处理

# 获取当前技能
func get_skill() -> String:
	return current_skill

# 设置技能
func set_skill(skill_name: String) -> void:
	current_skill = skill_name
	# 更新技能槽的显示
	update_display()

# 更新技能槽的视觉显示
func update_display():
	if current_skill != "":
		var skill_name = current_skill.replace("*", "×")
		var image_path = "res://image/" + skill_name
		var texture = load(image_path + ".jpg")
		if not texture:
			texture = load(image_path + ".png")
		if texture:
			$DropArea2/IconDisplay.texture = texture
			print("设置技能图标：", skill_name)
	else:
		$DropArea2/IconDisplay.texture = null
		print("清除技能图标")

func _on_gui_input(event):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed and current_skill != "":
			# 开始拖拽
			Global.drag_skill = current_skill
			current_skill = ""
			update_display()
		elif not event.pressed and Global.drag_skill != "" and current_skill == "":
			# 结束拖拽
			current_skill = Global.drag_skill
			Global.drag_skill = ""
			update_display()

# 声明支持拖放功能
func _get_drag_data(_position):
	if current_skill != "":
		var data = {"skill": current_skill, "source": self}
		var preview = TextureRect.new()
		var skill_name = current_skill.replace("*", "×")
		var image_path = "res://image/" + skill_name
		var texture = load(image_path + ".jpg")
		if not texture:
			texture = load(image_path + ".png")
		if texture:
			preview.texture = texture
			preview.custom_minimum_size = Vector2(64, 64)
			set_drag_preview(preview)
		return data
	return null

# 声明可以接收拖放
func _can_drop_data(_position, data):
	return data is Dictionary && data.has("skill") && current_skill == ""

# 处理拖放数据
func _drop_data(_position, data):
	if data is Dictionary && data.has("skill"):
		current_skill = data["skill"]
		update_display()
		
		# 触发新槽位生成
		if get_parent().has_method("check_add_new_slot"):
			get_parent().check_add_new_slot()
		return true
	return false
