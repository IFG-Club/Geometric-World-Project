extends Control

var slot_scene = preload("res://scenes/Slot.tscn")  # 预加载技能槽场景
var slot_spacing = 10  # 槽位之间的间距
var slots = []  # 存储所有的技能槽

func _ready():
	print("动态Slot容器初始化")
	# 添加第一个空槽位
	add_new_slot()

# 添加新的技能槽
func add_new_slot():
	var new_slot = slot_scene.instantiate()
	add_child(new_slot)
	slots.append(new_slot)
	
	# 更新所有槽位的位置
	update_slots_position()
	
	print("添加新的技能槽")
	print("当前槽位数量：", slots.size())
	return new_slot

# 检查是否需要添加新槽位
func check_add_new_slot():
	print("检查是否需要添加新槽位")
	var all_slots_filled = true
	
	# 检查是否所有槽都有技能
	for slot in slots:
		if slot.current_skill == "":
			all_slots_filled = false
			break
	
	# 如果所有槽都有技能，添加新槽
	if all_slots_filled:
		print("所有槽位已满，添加新槽位")
		add_new_slot()
	else:
		print("仍有空槽位，无需添加新槽位")

# 更新所有槽位的位置
func update_slots_position():
	var current_x = 0
	for slot in slots:
		slot.position.x = current_x
		current_x += slot.custom_minimum_size.x + slot_spacing

# 获取所有技能
func get_all_skills() -> Array:
	var skills = []
	for slot in slots:
		if slot.current_skill != "":
			skills.append(slot.current_skill)
	return skills

# 设置技能到空槽位
func set_skill_to_empty_slot(skill_name: String) -> bool:
	print("尝试设置技能到空槽位：", skill_name)
	
	# 先查找空槽位
	for slot in slots:
		if slot.current_skill == "":
			slot.set_skill(skill_name)
			print("成功设置技能到槽位")
			check_add_new_slot()  # 检查是否需要添加新槽位
			return true
	
	# 如果没有空槽位，添加新槽位并设置技能
	print("没有空槽位，添加新槽位并设置技能")
	var new_slot = add_new_slot()
	new_slot.set_skill(skill_name)
	return true 