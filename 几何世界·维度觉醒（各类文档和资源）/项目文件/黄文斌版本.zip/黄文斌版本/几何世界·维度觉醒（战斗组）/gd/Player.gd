# Player.gd
# 玩家角色的主要控制脚本
extends CharacterBody2D

@onready var skill_manager = get_node("/root/SkillManager")
@onready var bullet_scene = preload("res://scenes/Bullet.tscn")

#region 移动系统
# 玩家基础移动速度（像素/秒）
# 可在编辑器中调整此值以平衡游戏性
@export var movement_speed: float = 300.0

# 每个物理帧更新时处理玩家移动
func _physics_process(delta: float) -> void:
	# 获取玩家的WASD或方向键输入
	# 返回一个标准化的二维向量，表示移动方向
	var input_direction := Input.get_vector("left", "right", "up", "down")
	
	# 根据输入方向和移动速度计算实际速度
	velocity = input_direction * movement_speed
	
	# 使用内置的移动和碰撞处理系统
	# 自动处理与其他物体的碰撞
	move_and_slide()
	
	# 处理射击
	if Input.is_action_just_pressed("shoot"):
		shoot()
	


func _ready():
	print("玩家初始化")
	print("初始生命值：", current_health)
	print("最大生命值：", max_health)
	
	# 确保技能管理器已经准备好
	if skill_manager:
		print("技能管理器已连接")
		# 如果技能列表为空，添加基础技能"点"
		if skill_manager.selected_skills.is_empty():
			print("技能列表为空，添加基础技能'点'")
			skill_manager.selected_skills = ["点"]
		print("当前技能列表：", skill_manager.selected_skills)
	else:
		print("错误：找不到技能管理器！")

#region 技能系统
# 生命值系统
@export var max_health: float = 100.0
var current_health: float = max_health
var is_invincible: bool = false
var invincibility_duration: float = 1.0  # 无敌时间（秒）

# 伤害数字场景
var damage_number_scene = preload("res://scenes/DamageNumber.tscn")

# 处理输入事件
func _input(event: InputEvent) -> void:
	# 检测鼠标左键点击
	if event is InputEventMouseButton:
		var mouse_event = event as InputEventMouseButton
		if mouse_event.button_index == MOUSE_BUTTON_LEFT and mouse_event.pressed:
			shoot()

# 处理射击逻辑
func shoot():
	var current_skill = skill_manager.get_current_skill()
	print("尝试发射子弹")
	print("当前技能：", current_skill)
	
	if current_skill.is_empty():
		print("没有选择技能，无法发射")
		return
	
	# 获取当前技能的效果
	var effects = skill_manager.get_current_skill_effects()
	print("技能效果：", effects)
	
	# 根据效果创建子弹
	for i in range(effects.count):
		var bullet = bullet_scene.instantiate()
		bullet.position = position
		
		# 获取鼠标位置并计算基础方向
		var mouse_pos = get_global_mouse_position()
		var base_direction = (mouse_pos - position).normalized()
		
		# 如果有多发子弹，计算散射角度
		var angle = 0.0
		if effects.count > 1:
			# 计算每个子弹的角度偏移
			var total_spread = effects.spread_angle
			var angle_step = total_spread / (effects.count - 1)
			angle = -total_spread / 2 + i * angle_step
		
		# 应用角度偏移
		var direction = base_direction.rotated(deg_to_rad(angle))
		
		# 设置子弹属性
		bullet.direction = direction
		bullet.speed = effects.speed
		bullet.damage = effects.damage
		bullet.skill_type = current_skill
		
		if effects.has_fire:
			bullet.fire_damage = effects.fire_damage
			bullet.fire_duration = effects.fire_duration
		
		get_parent().add_child(bullet)
		print("发射子弹：")
		print("- 位置：", bullet.position)
		print("- 方向：", bullet.direction)
		print("- 伤害：", bullet.damage)
		print("- 速度：", bullet.speed)
		print("- 技能类型：", bullet.skill_type)

# 受到伤害时的处理
func take_damage(amount: float) -> void:
	if is_invincible:
		print("处于无敌状态，免疫伤害")
		return
		
	current_health = max(0, current_health - amount)
	print("受到伤害：", amount)
	print("当前生命值：", current_health)
	show_damage_number(amount)
	
	# 触发无敌状态
	is_invincible = true
	print("进入无敌状态")
	
	# 创建定时器
	var timer = get_tree().create_timer(invincibility_duration)
	timer.timeout.connect(func(): 
		is_invincible = false
		print("无敌状态结束")
	)


# 显示伤害数字
func show_damage_number(amount: float) -> void:
	var damage_number = damage_number_scene.instantiate()
	damage_number.global_position = global_position + Vector2(0, -50)  # 在角色头顶显示
	damage_number.set_damage(amount)
	get_tree().root.add_child(damage_number)


# 处理燃烧效果
func apply_burn(damage_per_tick: float, duration: float) -> void:
	var ticks = int(duration)
	for i in range(ticks):
		await get_tree().create_timer(1.0).timeout
		if current_health > 0:  # 只在活着时受到燃烧伤害
			take_damage(damage_per_tick)
	
	
